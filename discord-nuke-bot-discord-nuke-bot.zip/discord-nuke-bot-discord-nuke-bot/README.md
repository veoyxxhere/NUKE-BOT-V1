# discord-nuke-bot
Discord nuke Bot source code 
**Not my Token**
1) Create a bot here https://discord.com/developers/docs/intro
2) Download and Extract the file, Copy the Token and insert on the .py file
3) You can custom the code with you discord
4) Enjoy
5) For any problems dm me on discord @gio9977
